## Render Pipeline Native

This contains the source code of the native C++ modules
of the RenderPipeline.

The documentation of the
modules can be found <a href="http://tobspr.me/renderpipeline/docs/html/">here</a>.
