
## Python Implementation

This is the Python implementation of the pipeline internals.

**This folder contains no documentation!**

To view the documented code, please head over to the C++ Modules at `code/native/source`,
which implement the same features but are commented!

Besides of not being commented, the code is not written efficient and not in a
pythonic way, too, and instead tries to match the C++ code as close as possible,
to make updates as easy as possible.
