
## rp-gui

This folder only contains helper classes for the pipeline gui.
It is not really part of the pipeline, and thus also does not follow the
pipeline code conventions.
