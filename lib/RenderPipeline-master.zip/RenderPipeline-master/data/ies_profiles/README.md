
# IES Profiles


### Source

This files were aqcuired from:
http://www.derekjenson.com/3d-blog/ies-light-profiles

### Finding new IES Profiles

You can download IES profile files from the vendors directly.
Here are some links to start with:

- http://www.colorkinetics.com/support/ies/
- http://www.seleconlight.com/index.php?option=com_content&view=article&id=475
- http://www.lithonia.com/photometrics.aspx


### Previewing IES Profiles

You can preview the profiles with a viewer like this:

http://www.photometricviewer.com

