
### Empty textures

This are the empty textures you can use in your models in case you don't have
a detailmap for example.

See the wiki for further information.
