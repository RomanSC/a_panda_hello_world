Put your shaders into this directory.

--

You can access shader files with self.get_shader_resource("shader_name.frag.glsl")

--

You can access load shader files inside of a RenderStage with:

self.load_plugin_shader("shader_name.frag.glsl")

