Put your textures / models and other resources into this folder.

You can access them with get_resource("resource_name.ext")

