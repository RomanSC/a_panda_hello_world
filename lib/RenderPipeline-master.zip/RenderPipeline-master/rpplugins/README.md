
## Plugins

This is the plugin directory of the pipeline. It contains all plugins, including
their source code, resources and shaders.

In case anybody ever makes plugins for the pipeline, you would want to copy
them into this folder to make them available for the render pipeline.
