

# Filmic resopnse curves

The filmic curves were copied from blender and can be found in `datafiles/colormanagement/luts`.
It seems these luts are from http://opencolorio.org.

