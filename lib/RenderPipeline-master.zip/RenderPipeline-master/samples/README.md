## Render Pipeline Samples

The samples are not included in this repository to keep the size small.

#### Automatic Download (recommended)
You can run `python download_samples.py` to automatically download the samples.

#### Manual Download
If you want to manually download the samples (for whatever reason), you can
find them here:
<a href="https://github.com/tobspr/RenderPipeline-Samples
">https://github.com/tobspr/RenderPipeline-Samples</a>

After downloading, place the downloaded contents in this folder to run the samples.
