## RP Distributor

This makes a distributed copy of the render pipeline, with all not-necessary
files (like the whole toolkit/ folder) removed.

