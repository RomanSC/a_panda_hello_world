
## Importing real-world sun data

This script imports real world sun position data into the pipeline.
Edit `import_data.py` so it contains the date and location where the data
should be fetched for.

The script will then download the sun data for different times of the day
and configure the render pipeline to match those locations.


### Requirements

- Internet connection
