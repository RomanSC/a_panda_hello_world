
# Pathtracer Reference

This is a utility tool to generate a pathtracer reference.
You need to get a copy of the Mitsuba renderer, and copy it to `C:/mitsuba`.

The Mitsuba renderer can be acquired from:

https://www.mitsuba-renderer.org/download.html
