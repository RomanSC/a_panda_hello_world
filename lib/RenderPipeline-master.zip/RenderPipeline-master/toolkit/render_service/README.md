
## Render service

This is a tool to generate previews and renders of materials.
It keeps the render pipeline running in the background, and renders scenes
on demand.

A render can be triggered over the network. Example code for triggering a render
and waiting for completion can be found in `example_usage.py`


